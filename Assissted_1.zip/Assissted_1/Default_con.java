package Assissted;

public class Default_con {
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Default_con emp1=new Default_con();
		Default_con emp2=new Default_con();

		emp1.display();
		emp2.display();
	}

}
