package Assissted1;

public class Inner_cls_2 {
	private String msg="Inner Classes";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
		 Inner l=new Inner();  
		  l.msg();  

	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inner_cls_2 ob=new Inner_cls_2 ();  
		ob.display();  

	}

}
