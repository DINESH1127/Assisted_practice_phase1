package Assissted;

public class Method {
	
	public int multipynumbers(int a,int b) {
		int z=a*b;
		return z;
	}
	int val=150;

	int operation(int val) {
		val =val*10/100;
		return(val);
	}
	
	public void area(int b,int h)
    {
         System.out.println("Area of Triangle : "+(0.5*b*h));
    }
    public void area(int r) 
    {
         System.out.println("Area of Circle : "+(3.14*r*r));
    }

    
	public static void main(String[] args) {
		
		Method b=new Method();
		int ans= b.multipynumbers(54,85);
		System.out.println("Multipilcation is :"+ans);
		
		Method d = new Method();
		System.out.println("Before operation value of data is "+d.val);
		int g = d.operation(100);
		System.out.println("After operation value of data is "+g);
		
		Method ob=new Method();
	       ob.area(45,12);
	       ob.area(50);  

	}

}
