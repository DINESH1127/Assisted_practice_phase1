package Assissted;

public class Para_Con {
	int id;
	String name;

	Para_Con(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Para_Con std1=new Para_Con(2,"Alex");
		Para_Con std2=new Para_Con(10,"Annie");
		std1.display();
		std2.display();

	}

}
