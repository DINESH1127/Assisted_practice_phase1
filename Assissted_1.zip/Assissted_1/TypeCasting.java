package Assissted;

public class TypeCasting {

		public static void main(String[] args) {
			
			//implicit conversion
			System.out.println("Implicit Type Casting");
			char a='F';
			System.out.println("Value of a: "+a);
			
			int b=a;
			System.out.println("Value of b: "+b);
			
			float c=a;
			System.out.println("Value of c: "+c);
			
			long d=a;
			System.out.println("Value of d: "+d);
			
			double e=a;
			System.out.println("Value of e: "+e);
			
					
			System.out.println("\n");
			
			System.out.println("Explicit Type Casting");
			//explicit conversion
			
			double x=8.654498498498;
			int y=(int)x;
			System.out.println("Value of x: "+x);
			System.out.println("Value of y: "+y);
			float f = 75.564f;
			long l= (long)f;
			System.out.println(" The explicit conversion is " +l);
			
			
			double p = 565524.52646464;
			long ll = (long) p;
			int g1 = (int)ll;
			char i = (char) g1;
			System.out.println(" The explicit conversion is " +i);
			
			
			long j = 4674687687L;
			byte k = (byte) j;
			System.out.println(" The explicit conversion is " +k);
			
			
			int o=5405;
			double m = o;
			long n = (long) m;
			System.out.println(" The explicit conversion is " +n);
			
		}
	}
