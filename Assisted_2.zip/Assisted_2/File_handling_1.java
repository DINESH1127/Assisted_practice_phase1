package Assisted_2;

import java.util.Scanner;

import java.io.*;


class FileOperation{
		String path = "E://JAVA//File_handling//";
		Scanner s = new Scanner(System.in);


public void CreateFile() throws IOException {
	System.out.println("enter the file name: ");
	String filename = s.nextLine();
	String filepath = (path+filename);
	File f1 =new File(filepath);
	boolean b= f1.createNewFile();
	if (b != true)
	{
		System.out.println("files is not created");
	}
	else
	{
		System.out.println("files is created");
	}
	
}
public void ReadFile() throws IOException{
	System.out.println("enter the file name: ");
	String filename = s.nextLine();
	String filepath = (path+filename);
	File f1 =new File(filepath);
	FileInputStream q = new FileInputStream(filepath);
	int i;
	while((i=q.read()) != -1)
	{
		System.out.print((char)i);
	}
	q.close();

}

public void WriteFile() throws IOException{
	System.out.println("enter the file name: ");
	String filename = s.nextLine();
	String filepath = (path+filename);
	
	DataInputStream i = new DataInputStream(System.in);
	FileOutputStream o = new FileOutputStream(filepath,true);
	BufferedOutputStream p = new BufferedOutputStream(o,1024);
	System.out.println("Enter text (@ at the end):"); 
    char ch; 

    try {
		while((ch=(char)i.read())!='@') 
		  { 
		      p.write(ch); 
		  }
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
    //close the file 
    p.close(); 
}
}


public class File_handling_1 {

public static void main(String[] args) throws IOException {
	
	int choice =1;
	while(choice==1 || choice==2 || choice==3 || choice == 4 ){
	System.out.println("\nChoose which operation has to be done!!"+"\n"+"1.Create a new file"+"\n"+"2.Read files"+"\n"+"3.Write or append the data in the files"+"\n"+"4.To exit");
	Scanner sc=new Scanner(System.in);
	FileOperation f=new FileOperation();
	choice=sc.nextInt();
	switch(choice) {
	case 1:
	        f.CreateFile();
	        break;
	case 2:
			f.ReadFile();
			break;
	case 3:
			f.WriteFile();
			break;
	case 4:
			return;
	
}
	}}}