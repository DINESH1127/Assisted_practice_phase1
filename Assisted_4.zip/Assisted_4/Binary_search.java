package Assisted_4;

public class Binary_search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int[] arr = {65,4,3241,87,231,98,321,84,654,57};
        int key = 98;
        int arrlength = arr.length;
        binarySearch(arr,0,key,arrlength);

	}
	public static void binarySearch(int[] arr, int start, int key, int length){
		int midValue = (start+length)/2;
        while(start<=length){

            if(arr[midValue]<key){

                start = midValue + 1;
            } else if(arr[midValue]==key){
                System.out.println("Element is found at index :"+midValue);
                break;
            }else {

                length=midValue-1;
            }
            midValue = (start+length)/2;
        }
            if(start>length){

                System.out.println("Element is not found");
            }

}



}
